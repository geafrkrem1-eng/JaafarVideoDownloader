#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.11.1 is required. Use the included GitHub Actions workflow if you do not have a local build environment." >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_HOME or ANDROID_SDK_ROOT must point to your Android SDK." >&2
  exit 1
fi
gradle --no-daemon clean :app:assembleDebug
mkdir -p build-output
cp app/build/outputs/apk/debug/app-debug.apk build-output/JaafarVideoDownloader-debug.apk
echo "APK created: build-output/JaafarVideoDownloader-debug.apk"
