# Jaafar Video Downloader — Android Project

Native Android application foundation built with **Kotlin + Jetpack Compose + Material 3**.

## Implemented in this project

- Arabic-first RTL interface and navy/electric-blue/cyan identity.
- Home, Downloads, Library, and Settings tabs.
- Dark/light theme toggle and language toggle control (the current screen copy is Arabic-first; full English localization remains a follow-up task).
- Paste URL from clipboard.
- Accept shared text links from Android Sharesheet.
- Local URL host recognition for YouTube, Facebook, Instagram, TikTok, X/Twitter, Telegram, Vimeo, Reddit, Pinterest, Dailymotion, Twitch, and Snapchat.
- **Real direct-file downloads** through Android `DownloadManager` for direct HTTP/HTTPS media URLs ending in supported extensions: MP4, M4V, WebM, MOV, MP3, M4A, AAC, WAV.
- Download notification, progress/status display, cancel/remove, and completed-download listing.
- Video files are saved under the public `Movies/Jaafar/` directory; audio files downloaded directly are saved under `Music/Jaafar/`.
- Extract audio from completed downloaded videos to M4A using Android MediaExtractor/MediaMuxer; exported tracks are published to `Music/Jaafar/` through MediaStore so media apps can discover them.
- Six selectable accent palettes (cyan, violet, pink, green, amber, and blue), with selection persisted locally.
- GitHub Actions workflow at `.github/workflows/build-apk.yml` builds a debug APK and uploads it as an Actions artifact.

## Important platform limitation

Recognizing a social-media URL is not the same as having permission or a supported method to download its hosted media. This build does **not** extract media from YouTube/Facebook/Instagram/TikTok/etc. It does not bypass DRM, login walls, private-content restrictions, or platform protections. Those providers need separate official/authorized integrations and their own testing. The app reports that distinction instead of pretending that a social URL was downloaded.

## Build requirements

- Android Studio (current stable release recommended)
- JDK 17
- Android SDK Platform 35
- Gradle 8.11+ (Android Gradle Plugin 8.9.2)

## Build a debug APK

1. Extract this ZIP.
2. Open the `JaafarVideoDownloader` folder in Android Studio.
3. Allow Gradle sync and install missing SDK components if prompted.
4. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, from a terminal with Gradle and Android SDK configured:

```bash
./build-apk.sh
```

The script copies the resulting APK to `build-output/JaafarVideoDownloader-debug.apk`.

## App identity

- Application ID: `com.jaafar.videodownloader`
- Version: `1.1.0` (versionCode 3)
- Minimum Android: API 23 (Android 6.0)
- Target SDK: 35

## Release signing

A release APK must be signed with a keystore controlled by the app owner. No signing key or passwords are embedded in this project. Configure signing credentials locally in Android Studio/Gradle before publishing.


## Audio extraction and gallery visibility

The Library screen provides **استخراج الصوت** for completed downloads. This extracts the existing audio track to an `.m4a` file; it does not transcode to MP3. M4A was chosen as a reliable Android-native output without bundling FFmpeg. Some source codecs may not be supported by the device's MP4 muxer.

For APK builds using GitHub, push the repository to GitHub and run the workflow in the Actions tab. Download the `JaafarVideoDownloader-debug-apk` artifact from the completed run.
