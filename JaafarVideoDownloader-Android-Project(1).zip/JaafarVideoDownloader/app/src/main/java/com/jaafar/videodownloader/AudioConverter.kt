package com.jaafar.videodownloader

import android.content.ContentValues
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream

/** Extracts the existing audio stream without re-encoding; output is M4A/AAC, not MP3. */
object AudioConverter {
    fun extractAudioAsM4a(context: Context, source: Uri, displayName: String): String {
        val extractor = MediaExtractor()
        val temp = File.createTempFile("jaafar_audio_", ".m4a", context.cacheDir)
        var muxer: MediaMuxer? = null
        try {
            val pfd = context.contentResolver.openFileDescriptor(source, "r")
                ?: error("تعذر فتح ملف الفيديو")
            pfd.use { extractor.setDataSource(it.fileDescriptor) }
            val audioTrack = (0 until extractor.trackCount).firstOrNull { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("لا يحتوي الفيديو على مسار صوتي")
            val format = extractor.getTrackFormat(audioTrack)
            extractor.selectTrack(audioTrack)
            muxer = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer.addTrack(format)
            muxer.start()
            val buffer = java.nio.ByteBuffer.allocate(1024 * 1024)
            val info = android.media.MediaCodec.BufferInfo()
            while (true) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = extractor.sampleTime
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(0, buffer, info)
                extractor.advance()
            }
            muxer.stop()
            muxer.release()
            muxer = null
            extractor.release()
            saveToMusic(context, temp, displayName)
            return "تم استخراج الصوت وحفظه في مجلد الموسيقى بصيغة M4A"
        } finally {
            runCatching { muxer?.release() }
            runCatching { extractor.release() }
            temp.delete()
        }
    }

    private fun saveToMusic(context: Context, file: File, title: String) {
        val name = title.substringBeforeLast('.', title).replace(Regex("[^\\p{L}\\p{N}_ -]"), "_").take(70) + ".m4a"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Jaafar")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val uri = context.contentResolver.insert(collection, values) ?: error("تعذر إنشاء ملف الموسيقى")
        try {
            context.contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                ?: error("تعذر حفظ ملف الموسيقى")
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(uri, done, null, null)
            }
        } catch (e: Exception) {
            context.contentResolver.delete(uri, null, null)
            throw e
        }
    }
}
