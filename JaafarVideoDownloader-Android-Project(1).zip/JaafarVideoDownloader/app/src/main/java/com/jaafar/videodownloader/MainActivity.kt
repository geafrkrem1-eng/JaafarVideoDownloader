package com.jaafar.videodownloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URI

private val Navy = Color(0xFF071329)
private val Panel = Color(0xFF102342)
private val Panel2 = Color(0xFF142D50)
private val Cyan = Color(0xFF35D8FF)
private val Blue = Color(0xFF1677E8)
private val Muted = Color(0xFFA9BEDB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
        setContent { JaafarApp(this, shared) }
    }
}

private enum class Page(val title: String) { HOME("الرئيسية"), DOWNLOADS("التنزيلات"), LIBRARY("الملفات"), SETTINGS("الإعدادات") }
private data class Platform(val name: String, val mark: String, val tint: Color)
private data class DownloadItem(val id: Long, val title: String, val status: String, val progress: Int, val bytes: Long, val total: Long, val localUri: String?)
private val platforms = listOf(
    Platform("YouTube", "▶", Color(0xFFFF5A5A)), Platform("Facebook", "f", Color(0xFF559BFF)),
    Platform("Instagram", "◎", Color(0xFFE58BC1)), Platform("TikTok", "♪", Color.White),
    Platform("X", "𝕏", Color.White), Platform("Telegram", "➤", Color(0xFF48BDEB)),
    Platform("Vimeo", "v", Color(0xFF59A9FF)), Platform("Reddit", "r", Color(0xFFFF805C)),
    Platform("Pinterest", "p", Color(0xFFFF626B)), Platform("Dailymotion", "d", Cyan),
    Platform("Twitch", "▣", Color(0xFFB49BFF)), Platform("Snapchat", "s", Color(0xFFFFE35C))
)

@Composable
private fun JaafarApp(context: Context, initialUrl: String = "") {
    var page by remember { mutableStateOf(Page.HOME) }
    var url by remember { mutableStateOf(initialUrl) }
    var detected by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var english by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(true) }
    var refresh by remember { mutableIntStateOf(0) }
    var palette by remember { mutableIntStateOf(context.getSharedPreferences("jaafar_theme", Context.MODE_PRIVATE).getInt("palette", 0)) }
    var conversionMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val palettes = listOf(Color(0xFF35D8FF), Color(0xFFB388FF), Color(0xFFFF80AB), Color(0xFF69D2A3), Color(0xFFFFB74D), Color(0xFF64B5F6))
    val accent = palettes[palette.coerceIn(palettes.indices)]
    val clipboard = LocalClipboardManager.current
    val dm = remember { context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }
    val items = remember(refresh) { loadDownloads(context, dm) }
    val bg = if (dark) Navy else Color(0xFFF2F6FC)
    val surface = if (dark) Panel else Color.White
    val fg = if (dark) Color.White else Color(0xFF12213A)
    val muted = if (dark) Muted else Color(0xFF536782)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = accent, background = Navy, surface = Panel, onPrimary = Navy, onBackground = Color.White, onSurface = Color.White) else lightColorScheme(primary = accent, background = bg, surface = surface)) {
        Column(Modifier.fillMaxSize().background(bg)) {
            Header(surface, fg, english, { english = !english }, { dark = !dark })
            when (page) {
                Page.HOME -> HomeScreen(
                    url = url, onUrl = { url = it; detected = null; message = null },
                    onPaste = { url = clipboard.getText()?.text.orEmpty(); detected = null; message = null },
                    onAnalyze = {
                        detected = detectPlatform(url)
                        message = if (detected != null) "تم التعرف على ${detected}. روابط المنصات لا تعني أن التنزيل متاح؛ يلزم تكامل رسمي أو إذن من صاحب المحتوى." else if (isDirectMediaUrl(url)) "رابط ملف مباشر صالح مبدئياً. يمكنك بدء التنزيل." else "الرابط غير معروف. أدخل رابط ملف فيديو مباشر مثل MP4 أو رابطاً من منصة مدعومة."
                    },
                    detected = detected, message = message, fg = fg, muted = muted,
                    onDownload = {
                        val result = enqueueDirectDownload(context, dm, url)
                        message = result
                        refresh++
                    }
                )
                Page.DOWNLOADS -> DownloadsScreen(items, fg, muted, onRefresh = { refresh++ }, onCancel = { id -> dm.remove(id); refresh++ })
                Page.LIBRARY -> LibraryScreen(context, items, fg, muted, conversionMessage, onConvert = { item ->
                    conversionMessage = "جارٍ استخراج الصوت..."
                    scope.launch(Dispatchers.IO) {
                        val result = runCatching {
                            val uri = item.localUri?.let(Uri::parse) ?: error("تعذر العثور على ملف الفيديو")
                            AudioConverter.extractAudioAsM4a(context, uri, item.title)
                        }.getOrElse { "تعذر تحويل الملف: ${it.localizedMessage ?: "صيغة غير مدعومة"}" }
                        kotlinx.coroutines.withContext(Dispatchers.Main) { conversionMessage = result }
                    }
                }, onRefresh = { refresh++ })
                Page.SETTINGS -> SettingsScreen(dark, { dark = it }, english, { english = it }, palette, { palette = it; context.getSharedPreferences("jaafar_theme", Context.MODE_PRIVATE).edit().putInt("palette", it).apply() }, accent, fg, muted)
            }
            NavigationBar(selected = page, onSelect = { page = it }, surface = surface)
        }
    }
}

@Composable
private fun Header(surface: Color, fg: Color, english: Boolean, onLanguage: () -> Unit, onTheme: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(surface).padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Blue, Cyan)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(29.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("Jaafar", color = fg, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("VIDEO DOWNLOADER", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        }
        TextButton(onClick = onLanguage) { Text(if (english) "العربية" else "EN", color = fg) }
        IconButton(onClick = onTheme) { Icon(Icons.Default.DarkMode, null, tint = Cyan) }
    }
}

@Composable
private fun ColumnScope.HomeScreen(url: String, onUrl: (String) -> Unit, onPaste: () -> Unit, onAnalyze: () -> Unit,
                       detected: String?, message: String?, fg: Color, muted: Color, onDownload: () -> Unit) {
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF102D58), Color(0xFF0A1933))), RoundedCornerShape(24.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("مرحباً بك في", color = Muted, fontSize = 14.sp)
                Text("Jaafar", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("نزّل ملفات الفيديو المسموح بها بسهولة", color = Cyan, fontSize = 13.sp)
                Spacer(Modifier.height(17.dp))
                Box(Modifier.size(68.dp).background(Blue.copy(alpha = .25f), RoundedCornerShape(22.dp)).border(1.dp, Cyan.copy(alpha = .55f), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Download, null, tint = Cyan, modifier = Modifier.size(36.dp))
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("رابط الفيديو أو الملف", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onPaste) { Text("لصق الرابط", color = Cyan) }
                }
                Row(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(13.dp)).border(1.dp, Color(0xFF28476F), RoundedCornerShape(13.dp)).padding(horizontal = 13.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(value = url, onValueChange = onUrl, modifier = Modifier.weight(1f), singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp),
                        decorationBox = { inner -> if (url.isEmpty()) Text("الصق رابط MP4 أو رابطاً هنا...", color = Muted, fontSize = 13.sp); inner() })
                    Icon(Icons.Default.Link, null, tint = Cyan)
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = onAnalyze, enabled = url.isNotBlank(), modifier = Modifier.fillMaxWidth().height(49.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                    Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("تحليل الرابط", fontWeight = FontWeight.Bold)
                }
                if (message != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(message, color = if (detected != null || isDirectMediaUrl(url)) Color(0xFFFFD580) else Color(0xFFFF9999), fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
                }
                if (isDirectMediaUrl(url)) {
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onDownload, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087D68))) {
                        Icon(Icons.Default.Download, null); Spacer(Modifier.width(7.dp)); Text("تنزيل الملف المباشر")
                    }
                }
            }
        }
        item { Text("المنصات التي يتعرف التطبيق على روابطها", color = fg, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                platforms.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        row.forEach { p ->
                            Column(Modifier.weight(1f).background(if (fg == Color.White) Panel else Color.White, RoundedCornerShape(14.dp)).padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(p.mark, color = p.tint, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(4.dp)); Text(p.name, color = muted, fontSize = 11.sp)
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().background(if (fg == Color.White) Panel else Color.White, RoundedCornerShape(15.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = Cyan, modifier = Modifier.size(25.dp)); Spacer(Modifier.width(10.dp))
                Text("التطبيق ينزّل حالياً روابط ملفات الوسائط المباشرة فقط. لا يستخرج الفيديو من روابط المنصات الاجتماعية ولا يتجاوز قيودها.", color = muted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable
private fun ColumnScope.DownloadsScreen(items: List<DownloadItem>, fg: Color, muted: Color, onRefresh: () -> Unit, onCancel: (Long) -> Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مدير التنزيلات", color = fg, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = Cyan) }
        }
        if (items.isEmpty()) EmptyState(Icons.Default.Downloading, "لا توجد تنزيلات", "أضف رابط ملف مباشر من الصفحة الرئيسية.", muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { it.id }) { item ->
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VideoFile, null, tint = Cyan)
                        Spacer(Modifier.width(9.dp)); Text(item.title, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                        IconButton(onClick = { onCancel(item.id) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF7777)) }
                    }
                    LinearProgressIndicator(progress = { item.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Panel2)
                    Text("${item.status} • ${item.progress}% • ${formatBytes(item.bytes)} / ${formatBytes(item.total)}", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.LibraryScreen(context: Context, items: List<DownloadItem>, fg: Color, muted: Color, conversionMessage: String?, onConvert: (DownloadItem) -> Unit, onRefresh: () -> Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مكتبة التنزيلات", color = fg, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = Cyan) }
        }
        if (conversionMessage != null) Text(conversionMessage, color = Cyan, fontSize = 12.sp)
        val complete = items.filter { it.status == "مكتمل" }
        if (complete.isEmpty()) EmptyState(Icons.Default.VideoLibrary, "المكتبة فارغة", "ستظهر الملفات المكتملة هنا. تجدها أيضاً داخل مجلد Downloads في جهازك.", muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(complete, key = { it.id }) { item ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Movie, null, tint = Cyan, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text(item.title, color = Color.White, maxLines = 1); Text(formatBytes(item.bytes), color = Muted, fontSize = 11.sp) }
                    Column(horizontalAlignment = Alignment.End) {
                        TextButton(onClick = { onConvert(item) }) { Icon(Icons.Default.MusicNote, null); Text("استخراج الصوت") }
                        TextButton(onClick = {
                            val intent = Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        }) { Text("فتح التنزيلات") }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, muted: Color) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(58.dp)); Spacer(Modifier.height(14.dp))
        Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp)); Text(subtitle, color = muted, textAlign = TextAlign.Center, fontSize = 12.sp)
    }
}

@Composable
private fun ColumnScope.SettingsScreen(dark: Boolean, onDark: (Boolean) -> Unit, english: Boolean, onEnglish: (Boolean) -> Unit, palette: Int, onPalette: (Int) -> Unit, accent: Color, fg: Color, muted: Color) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("التفضيلات", color = fg, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        SettingRow("الوضع الداكن", "تغيير مظهر التطبيق", dark, onDark)
        SettingRow("اللغة الإنجليزية", "العربية هي اللغة الافتراضية", english, onEnglish)
        Text("اختر لون التطبيق", color = fg, fontWeight = FontWeight.Bold)
        val swatches = listOf(Color(0xFF35D8FF), Color(0xFFB388FF), Color(0xFFFF80AB), Color(0xFF69D2A3), Color(0xFFFFB74D), Color(0xFF64B5F6))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            swatches.forEachIndexed { index, color ->
                Box(Modifier.weight(1f).height(42.dp).background(color, RoundedCornerShape(13.dp)).border(if (palette == index) 3.dp else 0.dp, fg, RoundedCornerShape(13.dp)).clickable { onPalette(index) })
            }
        }
        Text("الفيديوهات تحفظ في Downloads، والصوت المستخرج بصيغة M4A يحفظ في Music/Jaafar ويظهر في تطبيقات الوسائط.", color = muted, fontSize = 12.sp)
        Text("الإصدار 1.0.1 • Jaafar Video Downloader", color = muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp) }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun NavigationBar(selected: Page, onSelect: (Page) -> Unit, surface: Color) {
    NavigationBar(containerColor = surface, contentColor = Cyan) {
        val icons = listOf(Icons.Default.Home, Icons.Default.Downloading, Icons.Default.VideoLibrary, Icons.Default.Settings)
        Page.values().forEachIndexed { index, page ->
            NavigationBarItem(selected = selected == page, onClick = { onSelect(page) }, icon = { Icon(icons[index], null) }, label = { Text(page.title, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Blue.copy(alpha = .22f)))
        }
    }
}

private fun detectPlatform(raw: String): String? {
    val host = runCatching { URI(raw.trim()).host?.lowercase()?.removePrefix("www.") }.getOrNull() ?: return null
    return when {
        host == "youtube.com" || host.endsWith(".youtube.com") || host == "youtu.be" -> "YouTube"
        host == "facebook.com" || host.endsWith(".facebook.com") || host == "fb.watch" -> "Facebook"
        host == "instagram.com" || host.endsWith(".instagram.com") -> "Instagram"
        host == "tiktok.com" || host.endsWith(".tiktok.com") -> "TikTok"
        host == "x.com" || host.endsWith(".x.com") || host == "twitter.com" || host.endsWith(".twitter.com") -> "X / Twitter"
        host == "t.me" || host == "telegram.me" || host.endsWith(".telegram.org") -> "Telegram"
        host == "vimeo.com" || host.endsWith(".vimeo.com") -> "Vimeo"
        host == "reddit.com" || host.endsWith(".reddit.com") || host == "redd.it" -> "Reddit"
        host == "pinterest.com" || host.endsWith(".pinterest.com") || host == "pin.it" -> "Pinterest"
        host == "dailymotion.com" || host.endsWith(".dailymotion.com") || host == "dai.ly" -> "Dailymotion"
        host == "twitch.tv" || host.endsWith(".twitch.tv") -> "Twitch"
        host == "snapchat.com" || host.endsWith(".snapchat.com") -> "Snapchat"
        else -> null
    }
}

private fun isDirectMediaUrl(raw: String): Boolean {
    val uri = runCatching { URI(raw.trim()) }.getOrNull() ?: return false
    if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) return false
    val path = uri.path.orEmpty().lowercase()
    return listOf(".mp4", ".m4v", ".webm", ".mov", ".mp3", ".m4a", ".aac", ".wav").any { path.endsWith(it) }
}

private fun enqueueDirectDownload(context: Context, manager: DownloadManager, raw: String): String {
    if (!isDirectMediaUrl(raw)) return "هذا ليس رابط ملف وسائط مباشر مدعوماً."
    return try {
        val uri = Uri.parse(raw.trim())
        val name = (uri.lastPathSegment ?: "jaafar_video.mp4").substringAfterLast('/').take(100).ifBlank { "jaafar_video.mp4" }
        val request = DownloadManager.Request(uri)
            .setTitle(name)
            .setDescription("Jaafar Video Downloader")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalPublicDir(if (name.substringAfterLast(".", "").lowercase() in listOf("mp3", "m4a", "aac", "wav")) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES, "Jaafar/$name")
        val id = manager.enqueue(request)
        val prefs = context.getSharedPreferences("jaafar_downloads", Context.MODE_PRIVATE)
        val old = prefs.getStringSet("ids", emptySet()).orEmpty().toMutableSet()
        old.add(id.toString()); prefs.edit().putStringSet("ids", old).apply()
        "تمت إضافة الملف إلى قائمة التنزيلات. تابع التقدم من تبويب التنزيلات."
    } catch (e: Exception) {
        "تعذر بدء التنزيل: ${e.localizedMessage ?: "خطأ غير معروف"}"
    }
}

private fun loadDownloads(context: Context, manager: DownloadManager): List<DownloadItem> {
    val ids = context.getSharedPreferences("jaafar_downloads", Context.MODE_PRIVATE).getStringSet("ids", emptySet()).orEmpty()
    return ids.mapNotNull { it.toLongOrNull() }.mapNotNull { id ->
        val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return@mapNotNull null
        cursor.use {
            if (!it.moveToFirst()) return@mapNotNull null
            val title = it.getString(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Video"
            val statusCode = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val bytes = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            val status = when (statusCode) {
                DownloadManager.STATUS_SUCCESSFUL -> "مكتمل"
                DownloadManager.STATUS_FAILED -> "فشل ($reason)"
                DownloadManager.STATUS_PAUSED -> "متوقف مؤقتاً"
                DownloadManager.STATUS_RUNNING -> "جارٍ التنزيل"
                else -> "بانتظار البدء"
            }
            val progress = if (total > 0) ((bytes * 100) / total).toInt().coerceIn(0, 100) else if (statusCode == DownloadManager.STATUS_SUCCESSFUL) 100 else 0
            val localUri = it.getString(it.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
            DownloadItem(id, title, status, progress, bytes, total, localUri)
        }
    }.sortedByDescending { it.id }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 0 -> "—"
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
}
