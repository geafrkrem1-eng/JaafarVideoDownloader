package com.jaafar.videodownloader

import android.app.DownloadManager
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URI
import java.nio.ByteBuffer

private data class AppPalette(
    val id: String, val name: String, val bg: Color, val panel: Color,
    val panel2: Color, val primary: Color, val accent: Color,
    val text: Color, val muted: Color
)

private val palettes = listOf(
    AppPalette("midnight", "كحلي ملكي", Color(0xFF071329), Color(0xFF102342), Color(0xFF142D50), Color(0xFF35D8FF), Color(0xFF1677E8), Color.White, Color(0xFFA9BEDB)),
    AppPalette("ocean", "المحيط", Color(0xFF061F2D), Color(0xFF0B3445), Color(0xFF12495B), Color(0xFF49E0D0), Color(0xFF078CBB), Color(0xFFF3FFFF), Color(0xFFA5D2D7)),
    AppPalette("purple", "البنفسجي", Color(0xFF130F2A), Color(0xFF241B43), Color(0xFF30245A), Color(0xFFC6A6FF), Color(0xFF805AD5), Color(0xFFFFFAFF), Color(0xFFC6B9E0)),
    AppPalette("emerald", "الزمرد", Color(0xFF071F1A), Color(0xFF10372D), Color(0xFF19483A), Color(0xFF70E0A1), Color(0xFF169B68), Color(0xFFF2FFF8), Color(0xFFA9D5BF)),
    AppPalette("sunset", "الغروب", Color(0xFF24120F), Color(0xFF3A211B), Color(0xFF513027), Color(0xFFFFC078), Color(0xFFE76F51), Color(0xFFFFF8F1), Color(0xFFE5BDAA)),
    AppPalette("rose", "الوردي", Color(0xFF26121F), Color(0xFF3C1D32), Color(0xFF522742), Color(0xFFFFA6CF), Color(0xFFD94F91), Color(0xFFFFF7FC), Color(0xFFE0B8CF)),
    AppPalette("light", "فاتح", Color(0xFFF1F5FB), Color.White, Color(0xFFE4ECF7), Color(0xFF0879D8), Color(0xFF1556A8), Color(0xFF14243A), Color(0xFF5D7088))
)

private enum class Page(val title: String) {
    HOME("الرئيسية"), DOWNLOADS("التنزيلات"), CONVERT("تحويل الصوت"), LIBRARY("المكتبة"), SETTINGS("الإعدادات")
}
private data class Platform(val name: String, val mark: String, val tint: Color)
private data class DownloadItem(val id: Long, val title: String, val status: String, val progress: Int, val bytes: Long, val total: Long)
private val platforms = listOf(
    Platform("YouTube", "▶", Color(0xFFFF5A5A)), Platform("Facebook", "f", Color(0xFF559BFF)),
    Platform("Instagram", "◎", Color(0xFFE58BC1)), Platform("TikTok", "♪", Color.White),
    Platform("X", "𝕏", Color.White), Platform("Telegram", "➤", Color(0xFF48BDEB)),
    Platform("Vimeo", "v", Color(0xFF59A9FF)), Platform("Reddit", "r", Color(0xFFFF805C)),
    Platform("Pinterest", "p", Color(0xFFFF626B)), Platform("Dailymotion", "d", Color(0xFF35D8FF)),
    Platform("Twitch", "▣", Color(0xFFB49BFF)), Platform("Snapchat", "s", Color(0xFFFFE35C))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 410)
        }
        setContent { JaafarApp(this, shared) }
    }
}

@Composable
private fun JaafarApp(context: Context, initialUrl: String = "") {
    val prefs = remember { context.getSharedPreferences("jaafar_settings", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf(Page.HOME) }
    var url by remember { mutableStateOf(initialUrl) }
    var detected by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var paletteId by remember { mutableStateOf(prefs.getString("palette", "midnight") ?: "midnight") }
    var refresh by remember { mutableIntStateOf(0) }
    val palette = palettes.firstOrNull { it.id == paletteId } ?: palettes.first()
    val clipboard = LocalClipboardManager.current
    val dm = remember { context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }
    val items = remember(refresh) { loadDownloads(context, dm) }
    MaterialTheme(colorScheme = darkColorScheme(primary = palette.primary, secondary = palette.accent, background = palette.bg, surface = palette.panel, onPrimary = palette.bg, onBackground = palette.text, onSurface = palette.text)) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Column(Modifier.fillMaxSize().background(palette.bg)) {
                Header(palette, onHome = { page = Page.HOME })
                when (page) {
                    Page.HOME -> HomeScreen(
                        url = url, onUrl = { url = it; detected = null; message = null },
                        onPaste = { url = clipboard.getText()?.text.orEmpty(); detected = null; message = null },
                        onAnalyze = {
                            detected = detectPlatform(url)
                            message = if (isDirectMediaUrl(url)) "رابط ملف وسائط مباشر. يمكنك بدء التنزيل." else if (detected != null) "تم التعرف على ${detected}. لا يعني ذلك أن التنزيل متاح؛ يلزم مصدر رسمي أو رابط ملف مباشر." else "الرابط غير معروف. جرّب رابط ملف فيديو مباشر مثل MP4."
                        },
                        detected = detected, message = message, palette = palette,
                        onDownload = { message = enqueueDirectDownload(context, dm, url); refresh++ }
                    )
                    Page.DOWNLOADS -> DownloadsScreen(items, palette, onRefresh = { refresh++ }, onCancel = { id -> dm.remove(id); refresh++ })
                    Page.CONVERT -> ConvertScreen(context, palette)
                    Page.LIBRARY -> LibraryScreen(context, items, palette, onRefresh = { refresh++ })
                    Page.SETTINGS -> SettingsScreen(palette, paletteId) { id ->
                        paletteId = id
                        prefs.edit().putString("palette", id).apply()
                    }
                }
                AppNavigation(selected = page, onSelect = { page = it }, palette = palette)
            }
        }
    }
}

@Composable
private fun Header(p: AppPalette, onHome: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(p.panel).padding(horizontal = 18.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(p.accent, p.primary)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(29.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("Jaafar", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("VIDEO DOWNLOADER", color = p.primary, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        }
        IconButton(onClick = onHome) { Icon(Icons.Default.Home, null, tint = p.primary) }
    }
}

@Composable
private fun ColumnScope.HomeScreen(
    url: String, onUrl: (String) -> Unit, onPaste: () -> Unit, onAnalyze: () -> Unit,
    detected: String?, message: String?, palette: AppPalette, onDownload: () -> Unit
) {
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(palette.panel2, palette.bg)), RoundedCornerShape(24.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("مرحباً بك في", color = palette.muted, fontSize = 14.sp)
                Text("Jaafar", color = palette.text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("نزّل ملفات الفيديو المسموح بها بسهولة", color = palette.primary, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Box(Modifier.size(68.dp).background(palette.accent.copy(alpha = .25f), RoundedCornerShape(22.dp)).border(1.dp, palette.primary.copy(alpha = .6f), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Download, null, tint = palette.primary, modifier = Modifier.size(36.dp))
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("رابط الفيديو أو الملف", color = palette.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onPaste) { Text("لصق الرابط", color = palette.primary) }
                }
                Row(Modifier.fillMaxWidth().background(palette.bg, RoundedCornerShape(13.dp)).border(1.dp, palette.muted.copy(alpha = .3f), RoundedCornerShape(13.dp)).padding(horizontal = 13.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(value = url, onValueChange = onUrl, modifier = Modifier.weight(1f), singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = palette.text, fontSize = 13.sp),
                        decorationBox = { inner -> if (url.isEmpty()) Text("الصق رابط MP4 أو رابطاً مباشراً هنا...", color = palette.muted, fontSize = 13.sp); inner() })
                    Icon(Icons.Default.Link, null, tint = palette.primary)
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = onAnalyze, enabled = url.isNotBlank(), modifier = Modifier.fillMaxWidth().height(49.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) {
                    Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("تحليل الرابط", fontWeight = FontWeight.Bold)
                }
                if (message != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(message, color = if (detected != null || isDirectMediaUrl(url)) Color(0xFFFFD580) else Color(0xFFFF9999), fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
                }
                if (isDirectMediaUrl(url)) {
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onDownload, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087D68))) {
                        Icon(Icons.Default.Download, null); Spacer(Modifier.width(7.dp)); Text("تنزيل إلى المعرض / الموسيقى")
                    }
                }
            }
        }
        item { Text("المنصات التي يتعرف التطبيق على روابطها", color = palette.text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                platforms.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        row.forEach { platform ->
                            Column(Modifier.weight(1f).background(palette.panel, RoundedCornerShape(14.dp)).padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(platform.mark, color = platform.tint, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(4.dp)); Text(platform.name, color = palette.muted, fontSize = 11.sp)
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().background(palette.panel, RoundedCornerShape(15.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = palette.primary, modifier = Modifier.size(25.dp)); Spacer(Modifier.width(10.dp))
                Text("يتعرف التطبيق على روابط المنصات، لكنه ينزّل حالياً روابط ملفات الوسائط المباشرة فقط، ولا يتجاوز قيود المنصات أو حقوق أصحاب المحتوى.", color = palette.muted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable
private fun ColumnScope.DownloadsScreen(items: List<DownloadItem>, p: AppPalette, onRefresh: () -> Unit, onCancel: (Long) -> Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مدير التنزيلات", color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = p.primary) }
        }
        if (items.isEmpty()) EmptyState(Icons.Default.Downloading, "لا توجد تنزيلات", "أضف رابط ملف مباشر من الصفحة الرئيسية.", p)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { it.id }) { item ->
                Column(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(15.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (item.title.substringAfterLast('.', "").lowercase() in listOf("mp3", "m4a", "aac", "wav")) Icons.Default.MusicNote else Icons.Default.VideoFile, null, tint = p.primary)
                        Spacer(Modifier.width(9.dp)); Text(item.title, color = p.text, modifier = Modifier.weight(1f), maxLines = 1)
                        IconButton(onClick = { onCancel(item.id) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF7777)) }
                    }
                    LinearProgressIndicator(progress = { item.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = p.primary, trackColor = p.panel2)
                    Text("${item.status} • ${item.progress}% • ${formatBytes(item.bytes)} / ${formatBytes(item.total)}", color = p.muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.ConvertScreen(context: Context, p: AppPalette) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            busy = true; status = "جارٍ استخراج الصوت..."; success = false
            scope.launch {
                val result = withContext(Dispatchers.IO) { runCatching { extractAacAudioToMusic(context, uri) } }
                busy = false
                result.onSuccess { path -> status = "تم حفظ الموسيقى بنجاح:\n$path"; success = true }
                    .onFailure { error -> status = error.message ?: "تعذر تحويل هذا الفيديو."; success = false }
            }
        }
    }
    Column(Modifier.weight(1f).fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("تحويل الفيديو إلى موسيقى", color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(22.dp)).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(88.dp).background(p.accent.copy(alpha = .18f), CircleShape).border(1.dp, p.primary.copy(alpha = .6f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, tint = p.primary, modifier = Modifier.size(44.dp))
            }
            Text("استخرج الصوت من فيديو محفوظ في هاتفك", color = p.text, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text("اختر ملف فيديو، وسيحفظ التطبيق المسار الصوتي بصيغة M4A داخل Music/Jaafar.", color = p.muted, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 19.sp)
            Button(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = p.accent)) {
                Icon(Icons.Default.VideoFile, null); Spacer(Modifier.width(8.dp)); Text("اختيار فيديو من الجهاز")
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = p.primary)
            if (status != null) {
                Text(status!!, color = if (success) Color(0xFF4ED69A) else p.muted, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
            }
        }
        Row(Modifier.fillMaxWidth().background(p.panel2, RoundedCornerShape(14.dp)).padding(13.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Info, null, tint = p.primary)
            Spacer(Modifier.width(9.dp))
            Text("حالياً يدعم الاستخراج المباشر للمسار الصوتي AAC فقط ويحفظه داخل حاوية M4A دون إعادة ترميز. إذا كان الفيديو يستخدم ترميزاً صوتياً آخر، سيظهر تنبيه بدلاً من إنشاء ملف غير صالح. لا يتم رفع الفيديو إلى الإنترنت.", color = p.muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun ColumnScope.LibraryScreen(context: Context, items: List<DownloadItem>, p: AppPalette, onRefresh: () -> Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مكتبة التنزيلات", color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = p.primary) }
        }
        val complete = items.filter { it.status == "مكتمل" }
        if (complete.isEmpty()) EmptyState(Icons.Default.VideoLibrary, "المكتبة فارغة", "ستظهر الملفات المكتملة هنا. تحفظ الفيديوهات في Movies/Jaafar والصوتيات في Music/Jaafar.", p)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(complete, key = { it.id }) { item ->
                Row(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(14.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (item.title.substringAfterLast('.', "").lowercase() in listOf("mp3", "m4a", "aac", "wav")) Icons.Default.MusicNote else Icons.Default.Movie, null, tint = p.primary, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text(item.title, color = p.text, maxLines = 1); Text(formatBytes(item.bytes), color = p.muted, fontSize = 11.sp) }
                    TextButton(onClick = { context.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("فتح", color = p.primary) }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, p: AppPalette) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = p.primary, modifier = Modifier.size(58.dp)); Spacer(Modifier.height(14.dp))
        Text(title, color = p.text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp)); Text(subtitle, color = p.muted, textAlign = TextAlign.Center, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun ColumnScope.SettingsScreen(p: AppPalette, selectedId: String, onSelect: (String) -> Unit) {
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("المظهر والألوان", color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item { Text("اختر الثيم الذي يناسب ذوقك. سيُحفظ اختيارك تلقائياً.", color = p.muted, fontSize = 12.sp) }
        items(palettes.chunked(2)) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { item ->
                    Column(Modifier.weight(1f).background(item.panel, RoundedCornerShape(16.dp)).border(if (item.id == selectedId) 2.dp else 1.dp, if (item.id == selectedId) item.primary else item.muted.copy(alpha = .25f), RoundedCornerShape(16.dp)).clickable { onSelect(item.id) }.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf(item.bg, item.panel, item.primary, item.accent).forEach { color -> Box(Modifier.weight(1f).height(25.dp).background(color, RoundedCornerShape(7.dp))) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(item.name, color = item.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), fontSize = 13.sp)
                            if (item.id == selectedId) Icon(Icons.Default.CheckCircle, null, tint = item.primary, modifier = Modifier.size(19.dp))
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(15.dp)).padding(14.dp)) {
                Text("أماكن حفظ الملفات", color = p.text, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                Text("الفيديوهات: Movies/Jaafar", color = p.muted, fontSize = 12.sp)
                Text("الموسيقى: Music/Jaafar", color = p.muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("Jaafar Video Downloader • الإصدار 1.1.0", color = p.primary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun AppNavigation(selected: Page, onSelect: (Page) -> Unit, palette: AppPalette) {
    NavigationBar(containerColor = palette.panel, contentColor = palette.primary) {
        val icons = listOf(Icons.Default.Home, Icons.Default.Downloading, Icons.Default.MusicNote, Icons.Default.VideoLibrary, Icons.Default.Palette)
        Page.values().forEachIndexed { index, page ->
            NavigationBarItem(selected = selected == page, onClick = { onSelect(page) }, icon = { Icon(icons[index], null) }, label = { Text(page.title, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = palette.primary, selectedTextColor = palette.primary, unselectedIconColor = palette.muted, unselectedTextColor = palette.muted, indicatorColor = palette.accent.copy(alpha = .2f)))
        }
    }
}

private fun detectPlatform(raw: String): String? {
    val host = runCatching { URI(raw.trim()).host?.lowercase()?.removePrefix("www.") }.getOrNull() ?: return null
    return when {
        host == "youtube.com" || host.endsWith(".youtube.com") || host == "youtu.be" -> "YouTube"
        host == "facebook.com" || host.endsWith(".facebook.com") || host == "fb.watch" -> "Facebook"
        host == "instagram.com" || host.endsWith(".instagram.com") -> "Instagram"
        host == "tiktok.com" || host.endsWith(".tiktok.com") -> "TikTok"
        host == "x.com" || host.endsWith(".x.com") || host == "twitter.com" || host.endsWith(".twitter.com") -> "X / Twitter"
        host == "t.me" || host == "telegram.me" || host.endsWith(".telegram.org") -> "Telegram"
        host == "vimeo.com" || host.endsWith(".vimeo.com") -> "Vimeo"
        host == "reddit.com" || host.endsWith(".reddit.com") || host == "redd.it" -> "Reddit"
        host == "pinterest.com" || host.endsWith(".pinterest.com") || host == "pin.it" -> "Pinterest"
        host == "dailymotion.com" || host.endsWith(".dailymotion.com") || host == "dai.ly" -> "Dailymotion"
        host == "twitch.tv" || host.endsWith(".twitch.tv") -> "Twitch"
        host == "snapchat.com" || host.endsWith(".snapchat.com") -> "Snapchat"
        else -> null
    }
}

private fun isDirectMediaUrl(raw: String): Boolean {
    val uri = runCatching { URI(raw.trim()) }.getOrNull() ?: return false
    if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) return false
    val path = uri.path.orEmpty().lowercase()
    return listOf(".mp4", ".m4v", ".webm", ".mov", ".mp3", ".m4a", ".aac", ".wav").any { path.endsWith(it) }
}

private fun enqueueDirectDownload(context: Context, manager: DownloadManager, raw: String): String {
    if (!isDirectMediaUrl(raw)) return "هذا ليس رابط ملف وسائط مباشر مدعوماً."
    return try {
        val uri = Uri.parse(raw.trim())
        val name = sanitizeFileName(uri.lastPathSegment ?: "jaafar_media.mp4")
        val ext = name.substringAfterLast('.', "").lowercase()
        val audio = ext in listOf("mp3", "m4a", "aac", "wav")
        val directory = if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        val mime = when (ext) {
            "mp4", "m4v" -> "video/mp4"; "webm" -> "video/webm"; "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "aac" -> "audio/aac"; "wav" -> "audio/wav"; else -> "application/octet-stream"
        }
        val request = DownloadManager.Request(uri)
            .setTitle(name).setDescription("Jaafar Video Downloader")
            .setMimeType(mime)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            .setDestinationInExternalPublicDir(directory, "Jaafar/$name")
        val id = manager.enqueue(request)
        val prefs = context.getSharedPreferences("jaafar_downloads", Context.MODE_PRIVATE)
        val old = prefs.getStringSet("ids", emptySet()).orEmpty().toMutableSet(); old.add(id.toString())
        prefs.edit().putStringSet("ids", old).apply()
        if (audio) "بدأ تنزيل الملف الصوتي. سيُحفظ في Music/Jaafar." else "بدأ تنزيل الفيديو. سيُحفظ في Movies/Jaafar ليظهر في المعرض."
    } catch (e: Exception) { "تعذر بدء التنزيل: ${e.localizedMessage ?: "خطأ غير معروف"}" }
}

private fun extractAacAudioToMusic(context: Context, source: Uri): String {
    val displayName = context.contentResolver.query(source, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else "video"
    } ?: "video"
    val baseName = sanitizeFileName(displayName.substringBeforeLast('.', displayName)).take(70).ifBlank { "jaafar_audio" }
    val temp = File(context.cacheDir, "${System.currentTimeMillis()}_jaafar_audio.m4a")
    val extractor = MediaExtractor()
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    try {
        extractor.setDataSource(context, source, null)
        var audioTrack = -1
        var audioFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
            if (mime == "audio/mp4a-latm") { audioTrack = i; audioFormat = format; break }
        }
        if (audioTrack < 0) throw IllegalArgumentException("لم يتم العثور على مسار AAC صوتي. هذا الإصدار يستخرج AAC فقط ويحفظه بصيغة M4A.")
        val selectedFormat = audioFormat ?: throw IllegalArgumentException("تعذر قراءة تنسيق المسار الصوتي.")
        val activeMuxer = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = activeMuxer
        val outputTrack = activeMuxer.addTrack(selectedFormat)
        activeMuxer.start(); muxerStarted = true
        extractor.selectTrack(audioTrack)
        val maxSize = if (selectedFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) selectedFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(256 * 1024) else 1024 * 1024
        val buffer = ByteBuffer.allocate(maxSize)
        val info = MediaCodec.BufferInfo()
        var samples = 0
        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            info.offset = 0; info.size = size; info.presentationTimeUs = extractor.sampleTime
            info.flags = extractor.sampleFlags
            activeMuxer.writeSampleData(outputTrack, buffer, info)
            samples++
            extractor.advance()
        }
        activeMuxer.stop(); muxerStarted = false; activeMuxer.release(); muxer = null
        if (samples == 0 || !temp.exists() || temp.length() == 0L) throw IllegalStateException("لم يحتوِ الفيديو على بيانات صوتية قابلة للاستخراج.")
        val fileName = "${baseName}.m4a"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/Jaafar")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val outputUri = context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("تعذر إنشاء ملف الموسيقى في الجهاز.")
            try {
                context.contentResolver.openOutputStream(outputUri, "w")!!.use { out -> temp.inputStream().use { it.copyTo(out) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(outputUri, done, null, null)
            } catch (e: Exception) {
                context.contentResolver.delete(outputUri, null, null); throw e
            }
            return "Music/Jaafar/$fileName"
        } else {
            val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "Jaafar")
            if (!folder.exists() && !folder.mkdirs()) throw IllegalStateException("تعذر إنشاء مجلد الموسيقى.")
            val output = File(folder, fileName)
            temp.copyTo(output, overwrite = true)
            MediaScannerConnection.scanFile(context, arrayOf(output.absolutePath), arrayOf("audio/mp4"), null)
            return output.absolutePath
        }
    } finally {
        if (muxerStarted) runCatching { muxer?.stop() }
        runCatching { muxer?.release() }
        runCatching { extractor.release() }
        temp.delete()
    }
}

private fun sanitizeFileName(input: String): String {
    val clean = input.substringAfterLast('/').replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(100)
    return clean.ifBlank { "jaafar_media.mp4" }
}

private fun loadDownloads(context: Context, manager: DownloadManager): List<DownloadItem> {
    val ids = context.getSharedPreferences("jaafar_downloads", Context.MODE_PRIVATE).getStringSet("ids", emptySet()).orEmpty()
    return ids.mapNotNull { it.toLongOrNull() }.mapNotNull { id ->
        val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return@mapNotNull null
        cursor.use {
            if (!it.moveToFirst()) return@mapNotNull null
            val title = it.getString(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Media"
            val statusCode = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val bytes = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            val status = when (statusCode) {
                DownloadManager.STATUS_SUCCESSFUL -> "مكتمل"; DownloadManager.STATUS_FAILED -> "فشل ($reason)"
                DownloadManager.STATUS_PAUSED -> "متوقف مؤقتاً"; DownloadManager.STATUS_RUNNING -> "جارٍ التنزيل"; else -> "بانتظار البدء"
            }
            val progress = if (total > 0) ((bytes * 100) / total).toInt().coerceIn(0, 100) else if (statusCode == DownloadManager.STATUS_SUCCESSFUL) 100 else 0
            DownloadItem(id, title, status, progress, bytes, total)
        }
    }.sortedByDescending { it.id }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 0 -> "—"; bytes < 1024 -> "$bytes B"; bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
}
