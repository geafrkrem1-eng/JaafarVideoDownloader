# Jaafar Video Downloader

Native Android application using Kotlin and Jetpack Compose.

## Features
- Arabic RTL interface.
- Multiple selectable color palettes.
- Direct HTTP(S) media downloads through Android DownloadManager.
- Video destinations: `Movies/Jaafar`.
- Audio destinations: `Music/Jaafar`.
- AAC audio extraction from a locally selected video to M4A.
- Download list, library, and settings screens.

## Important scope
Recognizing a social platform URL does not mean the app can download from that platform. The current downloader supports direct media-file URLs only. Platform-specific access must use authorized APIs or permitted download mechanisms. No DRM, login, private-content, or paywall bypass is implemented.

The current build does not transcode video resolutions and does not encode MP3. It preserves the quality supplied by the direct media URL and extracts compatible AAC audio to M4A.

## Build
See [BUILD-INSTRUCTIONS.txt](BUILD-INSTRUCTIONS.txt) for GitHub Actions instructions. The workflow builds a debug APK and uploads it as an artifact.
